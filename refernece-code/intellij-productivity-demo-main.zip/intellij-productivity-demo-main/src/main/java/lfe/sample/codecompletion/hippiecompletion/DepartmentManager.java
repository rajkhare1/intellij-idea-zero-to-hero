package lfe.sample.codecompletion.hippiecompletion;

public class DepartmentManager {
    private String departmentName;
    private String departmentCode;
    private int departmentCount;

    public void manageDepartment() {
        //dep
        //employee

    }
}

