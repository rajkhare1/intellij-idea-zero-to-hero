package lfe.sample.refactoring;

public class SampleUtility {
    public static void main(String[] args) {
        Sample sample = new Sample("P","Q");
        sample.setField3("R");
        sample.setField2("S");
    }
}
