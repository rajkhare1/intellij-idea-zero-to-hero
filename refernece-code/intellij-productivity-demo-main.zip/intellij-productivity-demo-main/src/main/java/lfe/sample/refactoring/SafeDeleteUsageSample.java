package lfe.sample.refactoring;

public class SafeDeleteUsageSample
{
    public static void main(String[] args) {
        SafeDeleteSample sample = new SafeDeleteSample("test");
    }
}
