package lfe.sample.navigation;

public class Parent extends Base{
    private String field1;
    private String field2;

    public void method1(){}
    public void method2(){}

}
