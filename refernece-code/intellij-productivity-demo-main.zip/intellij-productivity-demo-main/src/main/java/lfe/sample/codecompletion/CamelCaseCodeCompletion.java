package lfe.sample.codecompletion;

import lfe.sample.model.Person;
import lfe.sample.util.DataUtil;

public class CamelCaseCodeCompletion {
    public static void main(String[] args) {
        //Person person = DataUtil.gpm
    }
}
