package lfe.sample.navigation;

public class Base {


}
