package lfe.sample.codecompletion.hippiecompletion;

import lfe.sample.model.Employee;

import java.util.List;

public class EmployeeManager {
    private String employeeName;
    private int employeeId;
    private List<Employee> employeeList;
    private int employeeCount;

    public void processEmployee() {
        // Typing 'emp' here
    }

    public void addEmployee(String employeeName, int employeeId) {
        // Start typing 'employee' here...
    }
}

