package lfe.sample.refactoring;

public class SampleHelper {
    public static void main(String[] args) {
        Sample sample = new Sample("A","B");
        sample.setField2("C");
        int i = 100;
    }
}
