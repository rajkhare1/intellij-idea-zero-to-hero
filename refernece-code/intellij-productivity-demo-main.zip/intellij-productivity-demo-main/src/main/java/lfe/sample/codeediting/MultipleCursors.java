package lfe.sample.codeediting;

public class MultipleCursors {

}
