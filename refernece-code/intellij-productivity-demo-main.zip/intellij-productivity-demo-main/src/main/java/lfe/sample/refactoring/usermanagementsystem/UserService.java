package lfe.sample.refactoring.usermanagementsystem;

public class UserService {

    public User registerUser(User user) {
        //return new User(name,email);
        return user ;

    }


}

