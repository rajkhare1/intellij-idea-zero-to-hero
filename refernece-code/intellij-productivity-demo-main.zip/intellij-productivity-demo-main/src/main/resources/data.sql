INSERT INTO employees (first_name, last_name, email_id) VALUES ('John', 'Doe', 'john.doe@example.com');
INSERT INTO employees (first_name, last_name, email_id) VALUES ('Jane', 'Smith', 'jane.smith@example.com');
INSERT INTO employees (first_name, last_name, email_id) VALUES ('Alice', 'Johnson', 'alice.johnson@example.com');