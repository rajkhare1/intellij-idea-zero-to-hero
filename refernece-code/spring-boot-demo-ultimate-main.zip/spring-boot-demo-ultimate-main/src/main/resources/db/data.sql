INSERT INTO customer (first_name, last_name) VALUES ('Peter', 'Parker');
INSERT INTO customer (first_name, last_name) VALUES ('Bruce', 'Wayne');
INSERT INTO customer (first_name, last_name) VALUES ('Clark', 'Kent');
INSERT INTO customer (first_name, last_name) VALUES ('Tony', 'Stark');